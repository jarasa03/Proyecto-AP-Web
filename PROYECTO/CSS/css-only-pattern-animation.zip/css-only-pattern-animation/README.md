# CSS only Pattern Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/t_afif/pen/OJvBbxm](https://codepen.io/t_afif/pen/OJvBbxm).

